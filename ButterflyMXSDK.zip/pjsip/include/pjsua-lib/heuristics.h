#pragma once

#ifndef __HEURISTICS_H__
#define __HEURISTICS_H__


//#include <pjsua.h>





#endif