#define PJ_CONFIG_IPHONE 1
#define PJMEDIA_HAS_VIDEO 1
#define PJ_HAS_IPV6 1
#include <pj/config_site_sample.h>
