//
//  ButterflyMXSDK.h
//  ButterflyMXSDK
//
//  Created by Zhe Cui on 10/10/18.
//  Copyright © 2018 ButterflyMX. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ButterflyMXSDK.
FOUNDATION_EXPORT double ButterflyMXSDKVersionNumber;

//! Project version string for ButterflyMXSDK.
FOUNDATION_EXPORT const unsigned char ButterflyMXSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ButterflyMXSDK/PublicHeader.h>

