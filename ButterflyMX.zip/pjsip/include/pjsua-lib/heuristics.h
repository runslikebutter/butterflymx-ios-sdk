#pragma once

#ifndef __HEURISTICS_H__
#define __HEURISTICS_H__


//#include <pjsua.h>


void* badsipConnectionFunc;
pj_bool_t  catastrophic_failure(QosResult *res);


#endif