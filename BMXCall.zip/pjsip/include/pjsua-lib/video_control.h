#ifndef __VIDEO_CONTROL_H__
#define __VIDEO_CONTROL_H__

#define THIS_FILE   "video_control.c"


#endif