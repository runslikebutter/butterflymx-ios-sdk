//
//  ButterflyMXCallSDK.h
//  ButterflyMXCallSDK
//
//  Created by Sviatoslav Belmeha on 3/27/19.
//  Copyright © 2019 ButterflyMX. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ButterflyMXCallSDK.
FOUNDATION_EXPORT double ButterflyMXCallSDKVersionNumber;

//! Project version string for ButterflyMXCallSDK.
FOUNDATION_EXPORT const unsigned char ButterflyMXCallSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ButterflyMXCallSDK/PublicHeader.h>


